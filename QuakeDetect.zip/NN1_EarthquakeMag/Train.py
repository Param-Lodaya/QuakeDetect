import pandas as pd
from sklearn.preprocessing import StandardScaler as SS
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
import joblib
import os

Train_X = 'split_datasets/train_features.csv'
Train_Y = 'split_datasets/train_magnitude.csv'

Model_DIR = 'model_artifacts_nn' 
Scaler_File = os.path.join(Model_DIR, 'scaler_nn_relu.joblib') 
Model_File = os.path.join(Model_DIR, 'neural_network_relu_model.h5')

if not os.path.exists(Model_DIR):
    os.makedirs(Model_DIR)
    print(f"\nCreated directory for model artifacts: '{Model_DIR}'")

print("Started to Train the Neural Network!!")
try: 
  X = pd.read_csv(Train_X)
  Y = pd.read_csv(Train_Y)
  if isinstance(Y, pd.DataFrame) and Y.shape[1]==1:
   Y = Y.iloc[:, 0]
  print(f"Training features shape: {X.shape}, magnitude shape: {Y.shape}")
    
except FileNotFoundError as e:
    print(f"Error: Training data files not found ({e}). Ensure 'earthquake_data_splitter.py' was run.")
    exit()
except Exception as e:
    print(f"An unexpected error occurred during data loading: {e}")
    exit()

print("\nTransforming and Feature Scaling...")
scaler = SS()
X_scaled = scaler.fit_transform(X)
print("Features scaled successfully.")

input_dim = X_scaled.shape[1]
layer_1 = Dense(units=64, activation='relu', input_shape=(input_dim,))
layer_2 = Dense(units=32, activation='relu')
layer_3 = Dense(units=1, activation='linear')

model = Sequential([layer_1, layer_2, layer_3])
model.compile(optimizer='adam', loss='mse', metrics=['mae'])
model.summary()
history = model.fit(X_scaled,Y,epochs=50, batch_size=32, verbose=1)
print("/nNeural Network Model Trained!!")

print(f"\nSaving trained Neural Network model and scaler to '{Model_DIR}'...")
try:
   
    joblib.dump(scaler, Scaler_File)
    
    
    model.save(Model_File) 
    
    print("NN Model and Scaler saved successfully.")
except Exception as e:
    print(f"ERROR saving NN model or scaler: {e}")


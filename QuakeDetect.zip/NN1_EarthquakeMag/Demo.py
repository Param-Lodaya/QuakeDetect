import pandas as pd
import tensorflow as tf 
from tensorflow.keras.models import load_model 
from tensorflow.keras.metrics import MeanSquaredError, MeanAbsoluteError, R2Score
import joblib 
import os
import random # Import for random selection

Demo_X = 'split_datasets/demo_features.csv'
Demo_Y = 'split_datasets/demo_magnitude.csv' 

Model_DIR = 'model_artifacts_nn' 
Scaler_File = os.path.join(Model_DIR, 'scaler_nn_relu.joblib')
Model_File = os.path.join(Model_DIR, 'neural_network_relu_model.h5')


print("\nStarting Neural Network Demo Prediction Module ")
try:
    X_demo = pd.read_csv(Demo_X)
    y_demo = pd.read_csv(Demo_Y) 
    if isinstance(y_demo, pd.DataFrame) and y_demo.shape[1] == 1:
        y_demo = y_demo.iloc[:, 0]
    
    print(f"Demo features shape: {X_demo.shape}, magnitude shape: {y_demo.shape}")
    
except FileNotFoundError as e:
    print(f"Error: Demo data files not found ({e}). Ensure 'earthquake_data_splitter.py' was run.")
    exit()
except Exception as e:
    print(f"An unexpected error occurred during demo data loading: {e}")
    exit()


print(f"\nLoading trained Neural Network Model")
try:
    scaler = joblib.load(Scaler_File)
    nn_model = load_model(Model_File, custom_objects={
        'mse': MeanSquaredError,
        'mae': MeanAbsoluteError
    })
    print("NN Model and Scaler loaded successfully.")
except FileNotFoundError as e:
    print(f"Error: NN Model or Scaler file not found ({e}). Ensure 'earthquake_nn_trainer.py' was run successfully.")
    exit()
except Exception as e:
    print(f"An unexpected error occurred during model/scaler loading: {e}")
    import traceback
    traceback.print_exc()
    exit()

print("\nTransforming and Features Scaling")
X_demo_scaled = scaler.transform(X_demo)
print("Features scaled successfully.")

print("\n--- Interactive NN Demo Prediction ---")
print("\nYou can randomly select samples from the demo set and see their predictions.")
print("\nThe 'Input Features' are raw (unscaled) for easier understanding.")

while True:
    try:
        user_input = input("\nPress Enter to get a random prediction, or type 'q' to quit: ").strip().lower()
        if user_input == 'q':
            break

        if not X_demo.empty:
            random_index = random.randint(0, len(X_demo) - 1)

            single_X_row = X_demo.iloc[[random_index]]
            single_y_actual = y_demo.iloc[random_index]


            single_X_row_scaled = scaler.transform(single_X_row)


            single_y_pred = nn_model.predict(single_X_row_scaled, verbose=0)[0][0] 

            print(f"\n--- Random Demo Sample (Index: {random_index}) ---")
            print("Input Features:")
            print(single_X_row) # Display original input features
            
            print(f"\nActual Magnitude:    {single_y_actual:.4f}")
            print(f"Predicted Magnitude: {single_y_pred:.4f}")
            print(f"Difference:          {abs(single_y_actual - single_y_pred):.4f}")
            print("---------------------------------------")
        else:
            print("Demo set is empty. Cannot make predictions.")
            break

    except ValueError:
        print("Invalid input. Please press Enter or type 'q'.")
    except Exception as e:
        print(f"An error occurred during interactive prediction: {e}")
        # Print the full traceback to help debug
        import traceback
        traceback.print_exc()
        break # Exit loop on unhandled error

print("\n--- Neural Network Demo Prediction Module Complete ---")
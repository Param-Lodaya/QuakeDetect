import pandas as pd
from sklearn.preprocessing import StandardScaler as SS
import tensorflow as tf 
from tensorflow.keras.models import load_model 
from tensorflow.keras.metrics import MeanSquaredError, MeanAbsoluteError, R2Score 
import joblib 
import os

Test_X = 'split_datasets/test_features.csv'
Test_Y = 'split_datasets/test_magnitude.csv'

Model_DIR = 'model_artifacts_nn' 
Scaler_File = os.path.join(Model_DIR, 'scaler_nn_relu.joblib')
Model_File = os.path.join(Model_DIR, 'neural_network_relu_model.h5')

print("Starting Test Module!!")
try:
  X = pd.read_csv(Test_X)
  Y = pd.read_csv(Test_Y)
  if isinstance(Y, pd.DataFrame) and Y.shape[1]==1:
   Y = Y.iloc[:, 0]
  
  print(f"Testing features shape: {X.shape}, magnitude shape: {Y.shape}")

except FileNotFoundError as e:
    print(f"Error: Testing data files not found ({e}). Ensure 'earthquake_data_splitter.py' was run.")
    exit()
except Exception as e:
    print(f"An unexpected error occurred during testing data loading: {e}")
    exit()

print("\nLoading Trained Neural Network Model!!")

try:
  scaler = joblib.load(Scaler_File)
  model = load_model(Model_File, custom_objects={
    'mse': MeanSquaredError,
    'mae': MeanAbsoluteError
  })
  print("\nLoading Successful!")
except FileNotFoundError as e:
    print(f"Error: NN Model or Scaler file not found ({e}). Ensure 'earthquake_nn_trainer.py' was run successfully.")
    exit()
except Exception as e:
    print(f"An unexpected error occurred during model/scaler loading: {e}")
    exit()

print("\nTransforming and Feature Scaling!")
X_scaled = scaler.transform(X)
print("Scaling Successful!")

print("\nOverall Model Performance!")
loss, mae_val = model.evaluate(X_scaled, Y, verbose=0)

Y_prep = model.predict(X_scaled, verbose=0)
r2 = tf.keras.metrics.R2Score()
r2.update_state(Y, Y_prep)
r2_val = r2.result().numpy()

print(f"Test Mean Squared Error (MSE):  {loss:.4f}") # 'loss_test' is MSE from compile
print(f"Test Mean Absolute Error (MAE): {mae_val:.4f}")
print(f"Test R-squared (R2 Score):      {r2_val:.4f}")

print("\n--- Neural Network Testing Module Complete ---")

  
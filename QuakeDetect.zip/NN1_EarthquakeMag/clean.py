import pandas as pd
import numpy as np
import os # Import the os module for path manipulation

# --- Configuration ---
DATA_FILE_PATH = 'earthquake_data.csv'
# Define the names for the output cleaned files
OUTPUT_X_FILE_PATH = 'earthquake_features_cleaned.csv'
OUTPUT_Y_FILE_PATH = 'earthquake_magnitude_cleaned.csv'


# Define the numerical features that your ML model will use as input (X)
FEATURES_TO_USE = ['latitude', 'longitude', 'depth', 'gap', 'dmin', 'rms',
                   'horizontalError', 'depthError', 'magError', 'magNst']

# Define the target variable (y) for prediction
TARGET_VARIABLE = 'mag'

# --- 1. Load Data ---
try:
    df = pd.read_csv(DATA_FILE_PATH)
    print("Dataset loaded successfully.")
    print(f"Initial shape: {df.shape} (rows, columns)")
    print("First 5 rows (initial):")
    print(df.head())
except FileNotFoundError:
    print(f"Error: '{DATA_FILE_PATH}' not found. Please check the file path.")
    exit()
except Exception as e:
    print(f"An error occurred during data loading: {e}")
    exit()

# --- 2. Initial Data Inspection ---
print("\nDataset Info (initial):")
df.info()
print("\nMissing values before cleaning (count per column):")
print(df.isnull().sum())

# --- 3. Strict Missing Value Cleaning ---
initial_rows = df.shape[0]
df.dropna(inplace=True)
rows_after_dropna = df.shape[0]

print(f"\nMissing data removed.")
print(f"Rows before cleaning: {initial_rows}")
print(f"Rows after cleaning: {rows_after_dropna}")
print(f"Number of rows removed: {initial_rows - rows_after_dropna}")

# Verify no missing values remain
total_missing_after_cleaning = df.isnull().sum().sum()
if total_missing_after_cleaning == 0:
    print("Verification: No missing values remain in the dataset.")
else:
    print(f"WARNING: {total_missing_after_cleaning} missing values still found after dropna. Review your data.")


# --- 4. Feature Engineering for 'time' column ---
if 'time' in df.columns and not df['time'].empty:
    try:
        df['time'] = pd.to_datetime(df['time'])
        df['timestamp_unix'] = df['time'].apply(lambda x: x.timestamp())
        df['year'] = df['time'].dt.year
        df['month'] = df['time'].dt.month
        df['day'] = df['time'].dt.day
        df['hour'] = df['time'].dt.hour
        df['dayofweek'] = df['time'].dt.dayofweek

        print("\nTime-based features engineered successfully.")
    except Exception as e:
        print(f"Error engineering time features: {e}. Check 'time' column format.")
        engineered_time_features = ['timestamp_unix', 'year', 'month', 'day', 'hour', 'dayofweek']
        for col in engineered_time_features:
            if col in df.columns:
                df.drop(columns=[col], inplace=True)
else:
    print("\n'time' column not found or is empty after cleaning. Time-based features will not be available.")

# --- 5. Final Feature Set Definition ---
final_features_for_X = list(FEATURES_TO_USE)
engineered_time_features = ['timestamp_unix', 'year', 'month', 'day', 'hour', 'dayofweek']
for feature_col in engineered_time_features:
    if feature_col in df.columns:
        final_features_for_X.append(feature_col)

try:
    X_cleaned = df[final_features_for_X]
    y_cleaned = df[TARGET_VARIABLE]
    
    print(f"\nFinal features selected for model input (X_cleaned): {X_cleaned.columns.tolist()}")
    print(f"Target variable (y_cleaned): {TARGET_VARIABLE}")
    print(f"Shape of X_cleaned: {X_cleaned.shape}, Shape of y_cleaned: {y_cleaned.shape}")
    print("\nFirst 5 rows (after all cleaning and feature engineering):")
    print(X_cleaned.head())
except KeyError as e:
    print(f"Error: A column specified in features or target was not found after cleaning: {e}")
    print("Please check FEATURES_TO_USE and TARGET_VARIABLE lists against your actual DataFrame columns.")
    exit()

# --- 6. Save Cleaned Data to New CSV Files ---
try:
    X_cleaned.to_csv(OUTPUT_X_FILE_PATH, index=False)
    y_cleaned.to_csv(OUTPUT_Y_FILE_PATH, index=False)
    print(f"\nCleaned features saved to: '{OUTPUT_X_FILE_PATH}'")
    print(f"Cleaned magnitudes saved to: '{OUTPUT_Y_FILE_PATH}'")
except Exception as e:
    print(f"Error saving cleaned data: {e}")

print("\n--- Data Cleanup Complete ---")
print("The script has finished cleaning and preparing the data.")
print("The cleaned data has been saved to new CSV files.")
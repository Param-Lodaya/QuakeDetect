import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import os # Import os module to create directories

# --- Configuration ---
# Make sure your training CSV files are in the 'split_datasets' directory
TRAIN_FEATURES_FILE = 'split_datasets/train_features.csv'
TRAIN_MAGNITUDE_FILE = 'split_datasets/train_magnitude.csv'

# Define the directory where plots will be saved
PLOTS_OUTPUT_DIR = 'training_plots'

# --- 1. Load Training Data ---
try:
    X_train_df = pd.read_csv(TRAIN_FEATURES_FILE)
    y_train_series = pd.read_csv(TRAIN_MAGNITUDE_FILE)
    
    if isinstance(y_train_series, pd.DataFrame) and y_train_series.shape[1] == 1:
        y_train_series = y_train_series.iloc[:, 0]
    
    print("Training data loaded successfully.")
    
except FileNotFoundError:
    print(f"Error: Training data files '{TRAIN_FEATURES_FILE}' or '{TRAIN_MAGNITUDE_FILE}' not found.")
    print("Please ensure you have run 'earthquake_data_splitter.py' successfully.")
    exit()
except Exception as e:
    print(f"An error occurred during training data loading: {e}")
    exit()

# --- 2. Create Output Directory for Plots ---
if not os.path.exists(PLOTS_OUTPUT_DIR):
    os.makedirs(PLOTS_OUTPUT_DIR)
    print(f"\nCreated output directory for plots: '{PLOTS_OUTPUT_DIR}'")
else:
    print(f"\nOutput directory for plots '{PLOTS_OUTPUT_DIR}' already exists.")


# --- 3. Basic Descriptive Statistics for Training Set ---
print("\n--- Descriptive Statistics for Features (X_train) ---")
print(X_train_df.describe())
print("\n--- Descriptive Statistics for Magnitude (y_train) ---")
print(y_train_series.describe())


# --- 4. Visualize Distributions of Key Features in Training Set ---

X_train_df = X_train_df.reset_index(drop=True)
y_train_series = y_train_series.reset_index(drop=True)
df_train_combined = pd.concat([X_train_df, y_train_series.rename('magnitude')], axis=1)

plt.style.use('seaborn-v0_8-darkgrid')

# Helper function to save and close plot
def save_plot(filename, title):
    plt.title(title, fontsize=16) # Set title before tight_layout for better positioning
    plt.tight_layout()
    plt.savefig(os.path.join(PLOTS_OUTPUT_DIR, filename))
    print(f"Saved plot: '{filename}'")
    plt.close() # Close the plot to free memory and prevent it from displaying


# Histogram and KDE for Magnitude (Target Variable in Training Set)
plt.figure(figsize=(10, 6))
sns.histplot(df_train_combined['magnitude'], kde=True, bins=50, color='skyblue')
plt.xlabel('Magnitude', fontsize=12)
plt.ylabel('Count', fontsize=12)
save_plot('magnitude_distribution.png', 'Distribution of Earthquake Magnitude (Training Set)')


# Histograms for Depth and Gap in Training Set
plt.figure(figsize=(15, 6))
plt.subplot(1, 2, 1)
sns.histplot(df_train_combined['depth'], kde=True, bins=50, color='lightcoral')
plt.xlabel('Depth (km)', fontsize=12)
plt.ylabel('Count', fontsize=12)
plt.title('Distribution of Depth (Training Set)', fontsize=14) # Set subplot title directly

plt.subplot(1, 2, 2)
sns.histplot(df_train_combined['gap'], kde=True, bins=50, color='lightgreen')
plt.xlabel('Gap (degrees)', fontsize=12)
plt.ylabel('Count', fontsize=12)
plt.title('Distribution of Gap (Training Set)', fontsize=14) # Set subplot title directly
save_plot('depth_gap_distributions.png', 'Distributions of Depth and Gap (Training Set)')


# --- 5. Scatter Plots for Relationships with Magnitude in Training Set ---

# Magnitude vs. Depth
plt.figure(figsize=(10, 7))
sns.scatterplot(x='depth', y='magnitude', data=df_train_combined, alpha=0.5, hue='magnitude', palette='viridis', size='magnitude', sizes=(20, 400))
plt.xlabel('Depth (km)', fontsize=12)
plt.ylabel('Magnitude', fontsize=12)
plt.grid(True, linestyle='--', alpha=0.7)
save_plot('magnitude_vs_depth.png', 'Magnitude vs. Depth (Training Set)')


# Magnitude vs. Latitude & Longitude (Geographical Distribution in Training Set)
plt.figure(figsize=(12, 8))
# Assign the scatter plot to a variable 'scatter_plot'
scatter_plot = sns.scatterplot(x='longitude', y='latitude', hue='magnitude', size='magnitude', sizes=(10, 500),
                               palette='viridis', data=df_train_combined, alpha=0.6, edgecolor='w', linewidth=0.5)
plt.title('Geographical Distribution of Earthquakes by Magnitude (Training Set)', fontsize=16)
plt.xlabel('Longitude', fontsize=12)
plt.ylabel('Latitude', fontsize=12)
# Explicitly create the colorbar from the mappable object returned by scatter_plot
# The mappable object is usually the PathCollection, which is available via 'get_array()' from the return value if it's an AxesSubplot.
# Or, more simply, seaborn itself often returns the Axes object which has the mappable.
# The `cbar=True` and `cbar_kws` arguments are often preferred directly within sns.scatterplot for consistency.

# Option 1: Pass the mappable directly (more robust with plt.colorbar)
# The output of sns.scatterplot is an Axes object when data is provided.
# You can get the mappable from the scatter_plot axes.
# A simpler way is to use `sm.ScalarMappable` or let seaborn handle it if possible.

# Let's use the simplest, most common way to fix this with Seaborn - using cbar_kws directly in scatterplot
plt.close(plt.gcf()) # Close the previous empty figure created by plt.figure() if any.

plt.figure(figsize=(12, 8))
# Pass cbar_kws to scatterplot to let seaborn handle the colorbar creation
sns.scatterplot(x='longitude', y='latitude', hue='magnitude', size='magnitude', sizes=(10, 500),
                palette='viridis', data=df_train_combined, alpha=0.6, edgecolor='w', linewidth=0.5,
                cbar=True, # Ensure colorbar is drawn
                cbar_kws={'label': 'Magnitude'}) # Label the colorbar directly through seaborn
plt.title('Geographical Distribution of Earthquakes by Magnitude (Training Set)', fontsize=16)
plt.xlabel('Longitude', fontsize=12)
plt.ylabel('Latitude', fontsize=12)
# Removed the problematic plt.colorbar() line here
save_plot('geographical_distribution_magnitude.png', 'Geographical Distribution of Earthquakes by Magnitude (Training Set)')


# --- 6. Correlation Heatmap (for Numerical Features in Training Set) ---
numerical_cols = X_train_df.select_dtypes(include=np.number).columns.tolist()
if 'magnitude' not in numerical_cols:
    numerical_cols.append('magnitude')

cols_for_corr = [col for col in numerical_cols if col in df_train_combined.columns]

plt.figure(figsize=(12, 10))
correlation_matrix = df_train_combined[cols_for_corr].corr()
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=.5)
save_plot('correlation_heatmap.png', 'Correlation Matrix of Numerical Features (Training Set)')


# --- 7. Time-based plots for Training Set ---
# Note: These plots assume the 'year' and 'month' columns were successfully engineered and saved.

# Magnitude vs. Year (in Training Set)
if 'year' in df_train_combined.columns:
    plt.figure(figsize=(12, 6))
    sns.lineplot(x='year', y='magnitude', data=df_train_combined.groupby('year')['magnitude'].mean().reset_index(), marker='o')
    plt.xlabel('Year', fontsize=12)
    plt.ylabel('Average Magnitude', fontsize=12)
    save_plot('avg_magnitude_by_year.png', 'Average Earthquake Magnitude by Year (Training Set)')
else:
    print("\n'year' column not found in training data. Skipping 'Average Magnitude by Year' plot.")


# Earthquake Count per Month (across all years in Training Set)
if 'month' in df_train_combined.columns:
    plt.figure(figsize=(10, 6))
    sns.countplot(x='month', data=df_train_combined, palette='viridis')
    plt.xlabel('Month', fontsize=12)
    plt.ylabel('Count', fontsize=12)
    plt.xticks(ticks=np.arange(12), labels=['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])
    save_plot('earthquake_count_by_month.png', 'Earthquake Count by Month (Training Set)')
else:
    print("\n'month' column not found in training data. Skipping 'Earthquake Count by Month' plot.")


print(f"\n--- Data Visualization Complete ---")
print(f"All requested plots have been saved to the '{PLOTS_OUTPUT_DIR}' directory.")
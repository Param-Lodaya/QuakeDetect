import pandas as pd
from sklearn.model_selection import train_test_split
import os # Import os for path manipulation

# --- Configuration ---
# Input cleaned files (ensure these are in the same directory as this script)
FEATURES_FILE_PATH = 'earthquake_features_cleaned.csv'
MAGNITUDE_FILE_PATH = 'earthquake_magnitude_cleaned.csv'

# Output file paths for the split datasets
# You can customize these names and paths if you wish
OUTPUT_DIR = 'split_datasets' # Directory to save the split files

TRAIN_FEATURES_FILE = os.path.join(OUTPUT_DIR, 'train_features.csv')
TRAIN_MAGNITUDE_FILE = os.path.join(OUTPUT_DIR, 'train_magnitude.csv')

TEST_FEATURES_FILE = os.path.join(OUTPUT_DIR, 'test_features.csv')
TEST_MAGNITUDE_FILE = os.path.join(OUTPUT_DIR, 'test_magnitude.csv')

DEMO_FEATURES_FILE = os.path.join(OUTPUT_DIR, 'demo_features.csv')
DEMO_MAGNITUDE_FILE = os.path.join(OUTPUT_DIR, 'demo_magnitude.csv')

# --- 1. Load Cleaned Data ---
try:
    X_cleaned = pd.read_csv(FEATURES_FILE_PATH)
    y_cleaned = pd.read_csv(MAGNITUDE_FILE_PATH)
    
    # Ensure y_cleaned is a Series for consistent indexing and splitting
    if isinstance(y_cleaned, pd.DataFrame) and y_cleaned.shape[1] == 1:
        y_cleaned = y_cleaned.iloc[:, 0]
    
    print("Cleaned data loaded successfully.")
    print(f"Original features shape: {X_cleaned.shape}")
    print(f"Original magnitude shape: {y_cleaned.shape}")
    
except FileNotFoundError:
    print(f"Error: Cleaned data files '{FEATURES_FILE_PATH}' or '{MAGNITUDE_FILE_PATH}' not found.")
    print("Please ensure you have run 'earthquake_data_cleaner.py' successfully.")
    exit()
except Exception as e:
    print(f"An error occurred during data loading: {e}")
    exit()

# --- 2. Create Output Directory if it doesn't exist ---
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)
    print(f"\nCreated output directory: '{OUTPUT_DIR}'")
else:
    print(f"\nOutput directory '{OUTPUT_DIR}' already exists.")


# --- 3. Data Splitting (60% Train, 20% Test, 20% Demo) ---

# First split: Separate out 20% for the demo set.
# Remaining 80% will be used for training and testing.
X_temp, X_demo, y_temp, y_demo = train_test_split(X_cleaned, y_cleaned, test_size=0.20, random_state=42)

# Second split: From the remaining 80% (X_temp, y_temp), split 75% for training and 25% for testing.
# 75% of 80% is 60% (for training)
# 25% of 80% is 20% (for testing)
X_train, X_test, y_train, y_test = train_test_split(X_temp, y_temp, test_size=0.25, random_state=42)

print(f"\n--- Data Split Summary ---")
print(f"Training set shape (60%): X={X_train.shape}, y={y_train.shape}")
print(f"Testing set shape (20%): X={X_test.shape}, y={y_test.shape}")
print(f"Demo set shape (20%): X={X_demo.shape}, y={y_demo.shape}")

# --- 4. Save Split Data to CSV Files ---

try:
    # Save Training Set
    X_train.to_csv(TRAIN_FEATURES_FILE, index=False)
    y_train.to_csv(TRAIN_MAGNITUDE_FILE, index=False)
    print(f"\nTraining data saved to: '{TRAIN_FEATURES_FILE}' and '{TRAIN_MAGNITUDE_FILE}'")

    # Save Testing Set
    X_test.to_csv(TEST_FEATURES_FILE, index=False)
    y_test.to_csv(TEST_MAGNITUDE_FILE, index=False)
    print(f"Testing data saved to: '{TEST_FEATURES_FILE}' and '{TEST_MAGNITUDE_FILE}'")

    # Save Demo Set
    X_demo.to_csv(DEMO_FEATURES_FILE, index=False)
    y_demo.to_csv(DEMO_MAGNITUDE_FILE, index=False)
    print(f"Demo data saved to: '{DEMO_FEATURES_FILE}' and '{DEMO_MAGNITUDE_FILE}'")

except Exception as e:
    print(f"Error saving split data files: {e}")

print("\n--- Data Splitting and Saving Complete ---")
print(f"Your split datasets are now available in the '{OUTPUT_DIR}' directory.")